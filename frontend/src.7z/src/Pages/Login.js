import React from "react";
import LoginForm from "../Components/Loginform";

const Login = () => {
    return (
        <>
            <div>
                <LoginForm />
            </div>
        </>
    );
};

export default Login;
