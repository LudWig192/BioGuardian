//Contato
import React from "react";
import ContatoForm from '../Components/ContatoForm';

const Contato = () => {
  return (
    <>
      <div>
        <ContatoForm />
        {/* Conteúdo da página Contato */}
      </div>
    </>
  );
};

export default Contato;
