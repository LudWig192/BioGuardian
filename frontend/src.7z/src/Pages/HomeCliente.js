//Lista de Usuarios
import React from "react";
import Anatomy from "../Corpo/Anatomy";

const HomeCli = () => {
  return (
    <>
      <div>
        <Anatomy />
      </div>
    </>
  );
};

export default HomeCli;