import React from "react";
import CadastroForm from "../Components/CadastroForm";

const Cadastro = () => {
  return (
    <>
      <div>
        <CadastroForm />

      </div>
    </>
  );
};

export default Cadastro;